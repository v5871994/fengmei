<?php
if (!defined('IN_IA')) {
    exit('Access Denied');
}
return array(
    'version' => '1.1',
    'id' => 'qiniu',
    'name' => '七牛存储'
);
