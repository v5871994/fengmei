<?php
if (!defined('IN_IA')) {
    exit('Access Denied');
}
