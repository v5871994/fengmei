<?php
global $_W, $_GPC;

load()->func('tpl');
include $this->template('report');