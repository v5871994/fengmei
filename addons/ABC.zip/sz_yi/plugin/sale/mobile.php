<?php
//芸众商城 QQ:913768135
if (!defined('IN_IA')) {
    exit('Access Denied');
}
class SaleMobile extends Plugin
{
    public function __construct()
    {
        parent::__construct('sale');
    }
}