<?php
//芸众商城 QQ:913768135
if (!defined('IN_IA')) {
    exit('Access Denied');
}
return array('version' => '1.1', 'id' => 'poster', 'name' => '超级海报');