<?php

if (!defined('IN_IA')) {
    die('Access Denied');
}
return array('version' => '1.0', 'id' => 'exhelper', 'name' => '快递助手');