<?php
//芸众商城 QQ:913768135
if (!defined('IN_IA')) {
    exit('Access Denied');
}
return array(
    'version' => '1.0',
    'id' => 'permission',
    'name' => '分权系统'
);